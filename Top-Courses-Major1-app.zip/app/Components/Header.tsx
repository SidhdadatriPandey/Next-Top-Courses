'use client';
import React from 'react'

const Header = () => {
  return (
    <div>
      <h1 className='text-3xl font-bold m'>TOP COURSES</h1>
    </div>
  )
}

export default Header
